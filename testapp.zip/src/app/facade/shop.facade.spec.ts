import { TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';

import { ShopFacade } from './shop.facade';

describe('ShopFacade1', () => {
    let facade: ShopFacade;
    const state = {
        items: {
            name: "Product 1"
        }
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideMockStore({})
            ]
        });
        facade = TestBed.inject(ShopFacade);
    });

    it('should be created', () => {
        expect(facade).toBeTruthy();
    });
});