import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';
import { State } from 'src/app/store/shop.reducer';
import * as ShopSelectors from 'src/app/store/shop.selectors'


@Injectable({
  providedIn: 'root'
})
export class ShopFacade {

  items$ = this.store.pipe(select(ShopSelectors.selectItemsInBasket));
  
  constructor(private store: Store<State>) { }

  dispatch(action: Action) {
    this.store.dispatch(action);
  }

}