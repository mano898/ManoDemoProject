import { createAction, props } from '@ngrx/store';

export const addItems = createAction(
  '[Shop] Add Items',
  (item: any) => ({item})
  );

  export const removeItems = createAction(
    '[Shop] Remove Items',
    (index: number) => ({index})
    );
