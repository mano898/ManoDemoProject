import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from './shop.reducer';

export const getState = createFeatureSelector<State>('shop');

export const selectItemsInBasket = createSelector(
    getState,
    (state: any) => state.items.itemsInBasket
);
