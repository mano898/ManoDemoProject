import * as fromShop from './shop.actions';

describe('loadShops', () => {
  it('should return an action', () => {
    expect(fromShop.addItems({}).type).toBe('[Shop] Add Items');
  });

  it('should return an action', () => {
    expect(fromShop.removeItems(1).type).toBe('[Shop] Remove Items');
  });
});
