import { Action, createReducer, on } from '@ngrx/store';
import * as ShopActions from './shop.actions'


export const shopFeatureKey = 'shop';

export interface State {
  itemsInBasket: any;
}

export const initialState: State = {
  itemsInBasket: []
};


export const reducer = createReducer(
  initialState,
  on(ShopActions.addItems,
    (state: State, { item }) =>
    ({
      ...state,
      itemsInBasket: [...state.itemsInBasket, item]
    })),

    on(ShopActions.removeItems,
      (state: State, { index }) =>
      ({
        ...state,
        itemsInBasket: state.itemsInBasket.splice(index, 1)
      }))

);

