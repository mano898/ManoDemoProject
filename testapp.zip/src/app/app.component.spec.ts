import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { AppComponent } from './app.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { ShopFacade } from './facade/shop.facade';
import { NgxPopperModule } from 'ngx-popper';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { CartPopupDetailsComponent } from './components/cart-popup-details/cart-popup-details.component';

export class MockShopFacade{
  items$ = of([]);
  dispatch(){}
}

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        NgxPopperModule.forRoot({ placement: 'bottom' }),
        MatIconModule,
        MatTableModule
      ],
      declarations: [
        AppComponent,
        HeaderComponent,
        FooterComponent,
        CartPopupDetailsComponent
      ],
      providers: [
        {provide: ShopFacade, useClass:MockShopFacade}
      ]
      
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'test-app'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('test-app');
  });

});
