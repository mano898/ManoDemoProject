import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { NgxPopperModule } from 'ngx-popper';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ShopItemsComponent } from './components/shop-items/shop-items.component';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { CartPopupDetailsComponent } from './components/cart-popup-details/cart-popup-details.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ShopFacade } from './facade/shop.facade';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ShopItemsComponent,
    CartPopupDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    MatIconModule,
    MatTableModule,
    NgxPopperModule.forRoot({ placement: 'bottom' }),
    StoreModule.forRoot(reducers, { metaReducers }),
    StoreModule.forFeature('shop', reducers),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    NoopAnimationsModule
  ],
  providers: [ShopFacade],
  bootstrap: [AppComponent]
})
export class AppModule { }
