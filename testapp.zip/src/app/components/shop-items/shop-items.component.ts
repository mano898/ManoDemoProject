import { Component, OnDestroy, OnInit } from '@angular/core';
import { createAction, Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { State } from 'src/app/store/shop.reducer';
import * as ShopActions from 'src/app/store/shop.actions'
import {ShopFacade} from 'src/app/facade/shop.facade'

@Component({
  selector: 'app-shop-items',
  templateUrl: './shop-items.component.html',
  styleUrls: ['./shop-items.component.css']
})
export class ShopItemsComponent implements OnDestroy {
  shopItems: any;
  subscription: Subscription;

  constructor(private apiSevice: ApiService, private facade: ShopFacade) {
    this.subscription = this.apiSevice.getItems().subscribe((items: any) => {
      if (items && items.data) {
        this.shopItems = items.data
        console.log(this.shopItems);
      }
    });
  }

  addItemToCart(item) {
    this.facade.dispatch(ShopActions.addItems(item));
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
