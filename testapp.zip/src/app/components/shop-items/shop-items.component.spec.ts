import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ShopItemsComponent } from './shop-items.component';
import { Observable } from 'rxjs';
import { ShopFacade } from 'src/app/facade/shop.facade';


export class MockShopFacade{
  items$ = new Observable(null)
  dispatch(){}
}

describe('ShopItemsComponent', () => {
  let component: ShopItemsComponent;
  let fixture: ComponentFixture<ShopItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShopItemsComponent ],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        {provide: ShopFacade, useClass:MockShopFacade}
      ]
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
