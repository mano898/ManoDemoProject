import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-cart-popup-details',
  templateUrl: './cart-popup-details.component.html',
  styleUrls: ['./cart-popup-details.component.css']
})
export class CartPopupDetailsComponent implements OnInit {

  items:any = [];

  displayedColumns: string[] = ['productName', 'unitPrice', 'noOfItems', 'subtotal', 'remove'];

  @Input() set _basketItems(items: any){
    if(items){
      this.items = [...items]
    }
  };

  // @Output() remove_Item = new EventEmitter<any>();


  /** Gets the total price of all items. */
  getTotal() {
    return this.items.map(item => +item.price).reduce((acc, value) => acc + value, 0);
  }

  removeItem(index: number){
    // this.items.splice(index, 1)
    // this.remove_Item.emit(index);
  }
  constructor() { }

  ngOnInit(): void {
  }

}
