import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartPopupDetailsComponent } from './cart-popup-details.component';

describe('CartPopupDetailsComponent', () => {
  let component: CartPopupDetailsComponent;
  let fixture: ComponentFixture<CartPopupDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartPopupDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartPopupDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
