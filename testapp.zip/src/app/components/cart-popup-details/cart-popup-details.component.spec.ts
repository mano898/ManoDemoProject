import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { exception } from 'console';

import { CartPopupDetailsComponent } from './cart-popup-details.component';

describe('CartPopupDetailsComponent', () => {
  let component: CartPopupDetailsComponent;
  let fixture: ComponentFixture<CartPopupDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[MatTableModule, MatIconModule],
      declarations: [CartPopupDetailsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartPopupDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Assign value to items variable', () => {
    const items = [{
      description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
      id: 1,
      image: "http://truth-events.com/wp-content/uploads/2019/09/dummy.jpg",
      name: "Product 1",
      price: "100.00",
      quantity: "10"
    }]
    component._basketItems = items;
    expect(component.items).toEqual(items);
  });

  it('should calculate total', () => {
    const items = [{
      description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
      id: 1,
      image: "http://truth-events.com/wp-content/uploads/2019/09/dummy.jpg",
      name: "Product 1",
      price: "100.00",
      quantity: "10"
    },
    {
      description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
      id: 1,
      image: "http://truth-events.com/wp-content/uploads/2019/09/dummy.jpg",
      name: "Product 1",
      price: "100.00",
      quantity: "10"
    }]
    component._basketItems = items;
    expect(component.getTotal()).toEqual(200);
  });
});
