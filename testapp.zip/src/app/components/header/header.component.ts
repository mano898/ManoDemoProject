import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ShopFacade } from 'src/app/facade/shop.facade';
import * as ShopActions from 'src/app/store/shop.actions'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnDestroy {

  itemsInBasket: any;
  subscription: Subscription;

  constructor(private facade: ShopFacade) {
    this.subscription = this.facade.items$.subscribe(items => this.itemsInBasket = items);
  }

  removeItem(index: number){
    this.facade.dispatch(ShopActions.removeItems(index))
  }

  ngOnDestroy(){
    this.subscription.unsubscribe()
  }

}
