import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShopItemsComponent } from './components/shop-items/shop-items.component';


const routes: Routes = [
  { path: 'shop', component: ShopItemsComponent },
  { path: '',   redirectTo: '/shop', pathMatch: 'full' }, // redirect to `shop-items-component`
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
