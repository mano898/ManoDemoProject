import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../../environments/environment';
import { reducer } from '../store/shop.reducer';


export interface State {

}

export const reducers: ActionReducerMap<State> = {

  items: reducer

};


export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];
